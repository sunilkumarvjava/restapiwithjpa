package com.adpcodingtest.restapi.restapiwithjpa.dao;

import java.util.List;

import com.adpcodingtest.restapi.restapiwithjpa.user.User;

public interface UsersDAOService {


	public List<User> getUserByAdminFlag(String adminFlag);

	public List<User> getAllUsers();



}
