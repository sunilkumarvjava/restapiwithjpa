package com.adpcodingtest.restapi.restapiwithjpa.user;

import org.springframework.stereotype.Component;

@Component
public class GetUsersResponse {
	

	private String adminFlag;
	
	private String adminUsers;

	public String getAdminFlag() {
		return adminFlag;
	}

	public void setAdminFlag(String adminFlag) {
		this.adminFlag = adminFlag;
	}
	
	public String getAdminUsers() {
		return adminUsers;
	}

	public void setAdminUsers(String adminUsers) {
		this.adminUsers = adminUsers;
	}

	

}
