package com.adpcodingtest.restapi.restapiwithjpa.user;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	
	
	@Query("Select  u  From user_tab u where adminFlag = ?1")
	List<User> getUserByAdminFlag(String adminFlag);
	
	@Query("Select  u  From user_tab u ")
	List<User> getAllUsers();

}
