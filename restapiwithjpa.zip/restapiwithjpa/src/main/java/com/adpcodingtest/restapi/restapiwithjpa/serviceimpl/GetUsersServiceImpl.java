package com.adpcodingtest.restapi.restapiwithjpa.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adpcodingtest.restapi.restapiwithjpa.dao.UsersDAOService;
import com.adpcodingtest.restapi.restapiwithjpa.service.GetUsersService;
import com.adpcodingtest.restapi.restapiwithjpa.user.GetUsersResponse;
import com.adpcodingtest.restapi.restapiwithjpa.user.User;

@Service
public class GetUsersServiceImpl implements GetUsersService {

	@Autowired
	UsersDAOService usersDAOService;
	
	@Autowired
	GetUsersResponse response;
	
	@Override
	public List<User> getAllUsers() {
		return usersDAOService.getAllUsers();
	}

	@Override
	public GetUsersResponse getUserByAdminFlag(String adminFlag) {
		List<User> userByAdminFlag = usersDAOService.getUserByAdminFlag(adminFlag);
		List<String> adminUsersFirstNames = userByAdminFlag.stream()
				.flatMap(p -> Stream.of(p.getFirstName()))
				.collect(Collectors.toList());
		String adminUsers = String.join("| ", adminUsersFirstNames);
		System.out.println(adminUsersFirstNames);
		response.setAdminFlag(adminFlag);
		response.setAdminUsers(adminUsers);
		return response;
	}

}
