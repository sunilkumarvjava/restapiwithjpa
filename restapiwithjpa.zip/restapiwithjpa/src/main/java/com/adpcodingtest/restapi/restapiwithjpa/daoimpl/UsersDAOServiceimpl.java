package com.adpcodingtest.restapi.restapiwithjpa.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.adpcodingtest.restapi.restapiwithjpa.dao.UsersDAOService;
import com.adpcodingtest.restapi.restapiwithjpa.user.User;
import com.adpcodingtest.restapi.restapiwithjpa.user.UserRepository;

@Component 
public class UsersDAOServiceimpl implements UsersDAOService{
	
	@Autowired
	UserRepository userRepository;
	
	@Override
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}
	
	@Override
	public List<User> getUserByAdminFlag(String adminFlag) {
		
		return userRepository.getUserByAdminFlag(adminFlag);
	}

}
