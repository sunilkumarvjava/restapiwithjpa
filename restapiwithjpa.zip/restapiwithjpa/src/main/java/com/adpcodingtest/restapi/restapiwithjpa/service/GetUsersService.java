package com.adpcodingtest.restapi.restapiwithjpa.service;

import java.util.List;

import com.adpcodingtest.restapi.restapiwithjpa.user.GetUsersResponse;
import com.adpcodingtest.restapi.restapiwithjpa.user.User;

public interface  GetUsersService {

	public GetUsersResponse getUserByAdminFlag(String adminFlag);

	public List<User> getAllUsers();


}
