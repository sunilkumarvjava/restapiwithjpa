package com.adpcodingtest.restapi.restapiwithjpa.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.adpcodingtest.restapi.restapiwithjpa.service.GetUsersService;
import com.adpcodingtest.restapi.restapiwithjpa.user.GetUsersResponse;
import com.adpcodingtest.restapi.restapiwithjpa.user.User;

@RestController
@RequestMapping("schedule/v1")
public class UsersController {


	@Autowired
	private GetUsersService service;

	@GetMapping("/getAllUsers")
	public List<User> getAllUsers() {
		return service.getAllUsers();
	}
	@GetMapping("/users")
	public GetUsersResponse getUserByAdminFlag(@RequestParam (name = "adminFlag") String adminFlag) {

		return service.getUserByAdminFlag(adminFlag);

	}
	@GetMapping("/health")
	public String getUsersServiceHealth() {
		return "Service is Up and Running";

	}



}
