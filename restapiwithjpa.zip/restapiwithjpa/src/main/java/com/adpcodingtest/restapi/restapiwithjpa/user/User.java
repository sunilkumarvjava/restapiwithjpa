package com.adpcodingtest.restapi.restapiwithjpa.user;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name ="user_tab")
@Table(name = "user_tab")
public class User {

	@Id
	@GeneratedValue
	private Integer id;

	private String firstName;
	
	private String lastName;


    private String adminFlag;
	protected User() {

	}

	public User(Integer id, String firstName,String lastName, String adminFlag) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.adminFlag = adminFlag;

	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public String getAdminFlag() {
		return adminFlag;
	}

	public void setAdminFlag(String adminFlag) {
		this.adminFlag = adminFlag;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



}
