insert into user_tab values(10001,'T','NICK', 'ROB');
insert into user_tab values(10002,'T','Jill','MICK');
insert into user_tab values(10003,'F','Jam','JEFF');
insert into user_tab values(10004,'F','Dan','Juzer');
insert into user_tab values(10005,'T','Brand','Gorf');


